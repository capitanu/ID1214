SIMBRAIN 3.03

RUNNING SIMBRAIN

To run double click Simbrain.jar.   

(Linux users: This does not work on all distributions of linux.  An alternative is to open a terminal, navigate to where Simbrain.jar is located, and then enter the command "java -jar Simbrain.jar").

For more info see http://www.simbrain.net

You will need to have java 1.8 or later installed: http://www.oracle.com/technetwork/java/javase/downloads/index.html

GETTING STARTED

See here: https://www.youtube.com/watch?v=yYzUmcPaurI

Some things you can do to get a quick sense of how Simbrain works.

1) Open different workspaces using File > Open Workspace and press play in the in the workspace toolbar.

2) Run different scripts using the Script menu in the workspace menu, and pressing play in the workspace toolbar.

WHAT'S NEW

See release notes.