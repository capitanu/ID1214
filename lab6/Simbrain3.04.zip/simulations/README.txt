SIMULATIONS DIRECTORY README

This directory contains simulation files of various kinds.   (If you are downloading from svn then some of these folders will be incomplete).

- The workspaces directory contains full workspaces as .zip files.

- The networks directory contains neural networks as .xml files.

- The tables directory contains data as .csv or as .xml files.   The xml files can only be opened by simbrain table components.

- The worlds directory currently contains 2d world files  as .xml files.

- Other directories for storing other kinds of files (e.g. plots) may be added.