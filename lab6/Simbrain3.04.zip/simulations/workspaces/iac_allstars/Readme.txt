This folder contains some of the best homework IAC networks I've seen (I assign homeworks in a few classes where the goal is to build an IAC net).

- Jeff Yoshimi